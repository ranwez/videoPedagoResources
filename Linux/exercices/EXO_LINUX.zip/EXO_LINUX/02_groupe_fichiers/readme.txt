this directory contains some text files and a folder with sequence files in various format
